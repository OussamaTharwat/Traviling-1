<?php

namespace Modules\Rent\Database\Seeders;

use Illuminate\Database\Seeder;

class RentDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
