<?php

namespace Modules\Rent\Http\Controllers;

use App\Http\Controllers\Controller;

class RentController extends Controller
{
   //
}
