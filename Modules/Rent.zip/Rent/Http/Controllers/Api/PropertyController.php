<?php

namespace Modules\Rent\Http\Controllers\Api;

use Modules\Rent\Models\Property;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class PropertyController extends Controller
{
    public function index(Request $request)
    {
        // فلترة حسب الطلب (مثلاً: area_id, price, type) - اختياري
        $query = Property::query()
            ->where('is_available', true)
            ->where('status', 'approved');

        // مثال على فلترة بالمنطقة لو هتدعمها
        if ($request->has('area_id')) {
            $query->where('area_id', $request->area_id);
        }

        // ترتيب الأحدث أولاً
        $query->orderBy('created_at', 'desc');

        // تقسيم النتائج 10 في الصفحة
        $properties = $query->paginate(10);

        return response()->json([
            'status' => true,
            'data' => $properties
        ]);
    }
}
