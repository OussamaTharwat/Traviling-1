<?php

use Illuminate\Support\Facades\Route;
use Modules\Rent\Http\Controllers\Api\PropertyController;

// كل APIs لموديول Rent تبدأ هنا
Route::prefix('rent')->group(function () {
    Route::get('properties', [PropertyController::class, 'index']);
    // ممكن تضيف باقي APIs هنا بعدين
});
