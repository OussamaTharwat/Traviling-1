<?php

return [
    'name' => 'Rent',
];
